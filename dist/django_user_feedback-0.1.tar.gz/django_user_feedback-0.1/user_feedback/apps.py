from django.apps import AppConfig


class UserFeedbackConfig(AppConfig):
    name = 'user_feedback'
